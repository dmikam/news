=== Comment Notifier ===
Tags: comment, comments, subscription, subscribe, notify, notifier, discussion, thread, community, users, readers
Requires at least: 2.1
Tested up to: 2.7.1
Stable tag: trunk
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2545483
Contributors: satollo

A simple "new comment" notifier and "comments subscription" system.

== Description ==

In deep documentation on
[Comment Notifier official page](http://www.satollo.net/plugins/comment-notifier).

Comment Notifier lets a blog reader to subscribe to comments of a specific post
when he leaves his own comment.

Emails sent out to notify of new comments are fully customizable with HTML
formatting. Test emails can be sent from admin panel to verify the configurations and
a simple preview is available.

The subscribe checkbox can be added automatically or manually. A user can subscribe
following a link in notification messages. You can create such a link as you prefere
with the text on how to unsubscribe.

Version 2.0 has just been rewritten, so there is chances it has some new bugs.
I wait for your observations, write directly to info@satollo.net.

My plugins:

* [Protector](http://www.satollo.net/plugins/protector)
* [Post Layout](http://www.satollo.net/plugins/post-layout)
* [Post Layout Pro](http://www.satollo.net/plugins/post-layout-pro)
* [Other Posts](http://www.satollo.net/plugins/other-posts)
* [Newsletter](http://www.satollo.net/plugins/newsletter)
* [Header and Footer](http://www.satollo.net/plugins/header-footer)
* [Hyper Cache](http://www.satollo.com/english/wordpress/hyper-cache "Hyper Cache WordPress plugin: when performance and flexibilty are not an option")
* [Feed Layout](http://www.satollo.com/english/wordpress/feed-layout "Feed Layout WordPress plugin: the easy way to enrich your feed contents")

== Installation ==

1. Put the plugin folder into [wordpress_dir]/wp-content/plugins/
2. Go into the WordPress admin interface and activate the plugin
3. Optional: go to the options page and configure the plugin

== Frequently Asked Questions ==

No questions have been asked.

== Screenshots ==

No screenshots are available.